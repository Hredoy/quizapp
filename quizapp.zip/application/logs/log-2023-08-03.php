ERROR - 2023-08-03 13:02:32 --> Severity: Warning --> Undefined array key "tbl_coin_store" /opt/lampp/htdocs/Elite-quiz/application/models/Setting_model.php 306
ERROR - 2023-08-03 09:43:06 --> Severity: error --> Exception: syntax error, unexpected token "exit" /opt/lampp/htdocs/Elite-quiz/application/models/Coin_Store_model.php 21
ERROR - 2023-08-03 13:19:19 --> Severity: error --> Exception: Call to undefined method CI_Upload::errors() /opt/lampp/htdocs/Elite-quiz/application/models/Coin_Store_model.php 31
ERROR - 2023-08-03 13:19:36 --> Severity: error --> Exception: Call to undefined method CI_Upload::error() /opt/lampp/htdocs/Elite-quiz/application/models/Coin_Store_model.php 31
ERROR - 2023-08-03 13:20:10 --> Severity: error --> Exception: Call to undefined method CI_Upload::display_error() /opt/lampp/htdocs/Elite-quiz/application/models/Coin_Store_model.php 31
ERROR - 2023-08-03 13:29:55 --> Severity: Warning --> Attempt to read property "image" on array /opt/lampp/htdocs/Elite-quiz/application/controllers/Api.php 4179
